function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  
  noStroke();
  fill(2,700,40);
  circle(mouseX,mouseY,24);
}

function mousePressed(){
  background(0);
  
}